package com.lti.vehicle.dao;


	import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.vehicle.model.Claim;


	@Repository
	public interface IAdminDao {
		
		public List<Claim> claimlist();
		
		public void acceptClaim(int claimId);
		
		public void rejectUser(int claimId);
		
		public List<Claim> fetchClaimDetails(int claimId);
	}

