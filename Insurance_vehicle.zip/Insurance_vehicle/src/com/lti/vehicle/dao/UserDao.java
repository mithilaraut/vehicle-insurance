package com.lti.vehicle.dao;

	import org.springframework.stereotype.Repository;

import com.lti.vehicle.model.UserDetails;
	@Repository
	public interface UserDao {


		//UserDetails get(int id);
		
		
		void addUser(UserDetails u);
		boolean verifyUser(String email, String password);
		UserDetails getByEmail(String email);

		
	}
