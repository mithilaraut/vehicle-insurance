package com.lti.vehicle.service;

	import java.util.List;

	import org.springframework.stereotype.Service;

	import com.lti.vehicle.model.Claim;


	@Service
	public interface IAdminService {

		public List<Claim> claimlist();
		
		public void acceptClaim(int claimId);
		
		public void rejectUser(int claimId);
		
		public List<Claim> fetchClaimDetails(int claimId);
		
		
	}
