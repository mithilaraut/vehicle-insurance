package com.lti.vehicle.service;

import java.util.List;

import javax.transaction.Transactional;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.lti.vehicle.dao.IAdminDao;
import com.lti.vehicle.model.Claim;


@Service
@Transactional
public class AdminServiceImpl implements IAdminService{
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	

	@Autowired
	private IAdminDao iAdminDao;


	public IAdminDao getiAdminDao() {
		return iAdminDao;
	}


	public void setiAdminDao(IAdminDao iAdminDao) {
		this.iAdminDao = iAdminDao;
	}


	@Override
	public List<Claim> claimlist() {
		// TODO Auto-generated method stub
		return this.iAdminDao.claimlist();
	}

	@Override
	public void acceptClaim(int claimId) {
		// TODO Auto-generated method stub
		iAdminDao.acceptClaim(claimId);

		
		
	}

	@Override
	public void rejectUser(int claimId) {
		// TODO Auto-generated method stub
		iAdminDao.rejectUser(claimId);
		
	}

	@Override
	public List<Claim> fetchClaimDetails(int claimId) {
		// TODO Auto-generated method stub
		return iAdminDao.fetchClaimDetails(claimId);
	}
	
	

}
