package com.lti.vehicle.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="CLAIM")
public class Claim implements Serializable {

	@OneToOne(mappedBy="claim",cascade=CascadeType.ALL)
	private UserDetails userDetails;
	
	@OneToOne(mappedBy="claim",cascade=CascadeType.ALL)
	private Plans plans;
	
	
	public UserDetails getUserDetails() {
		return userDetails;
	}
	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}
	
	
	@OneToOne(mappedBy="tempClaim", cascade = CascadeType.ALL)
	 	private ApplicationInsurance applicationInsurance;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer claimId;
	private String claimDate;
	private String claimReason;
	
	public Integer getClaimId() {
		return claimId;
	}



	public void setClaimId(Integer claimId) {
		this.claimId = claimId;
	}



	public String getClaimDate() {
		return claimDate;
	}



	public void setClaimDate(String claimDate) {
		this.claimDate = claimDate;
	}



	public String getClaimReason() {
		return claimReason;
	}



	public void setClaimReason(String claimReason) {
		this.claimReason = claimReason;
	}



	@Override
	public String toString() {
		return "Claim [claimId=" + claimId + ", claimDate=" + claimDate + ", claimReason=" + claimReason + "]";
	}


     
	public Claim() {
		super();

	}
		
}
